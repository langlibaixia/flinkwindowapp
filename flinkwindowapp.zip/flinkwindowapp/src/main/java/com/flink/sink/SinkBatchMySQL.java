/*
 * Copyright (c) 2022. Langlibaixia 834009465@qq.com All Rights Reserved
 *  *  *  Project:   flinktumbleapp
 *  *  *  @ClassName:SinkToMySQL
 *  *  *  @Description:
 *  *  *  Version: 1.0
 *  ***************************************************************************************
 *  *  * 日期        类型   开发者   内容
 *  *  * 2022-04-04 新增   浪里白侠  创建内容
 *  ***************************************************************************************
 */

package com.flink.sink;

import com.flink.pojo.TransFlow;
import com.flink.util.DruidConnectionPool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * 程序功能: 数据批量 sink 数据到 mysql
 * */
public class SinkBatchMySQL extends RichSinkFunction<List<TransFlow>> implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(SinkTwoPhaseCommitMysql.class);
    PreparedStatement insertStmt = null;

    private Connection connection;

    // open() 方法中建立连接，这样不用每次 invoke 的时候都要建立连接和释放连接

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        //获取连接
        Connection connection = DruidConnectionPool.getConnection();
        //设定不自动提交
        //connection.setAutoCommit(false);

        String insert_sql = "insert into transflow(tradeno, tradename, trandeame, userid,createtime) values(?, ?, ?, ?, ?);";
        insertStmt = connection.prepareStatement(insert_sql);
    }

    @Override
    public void close() throws SQLException {

        if (connection != null) {
            connection.close();
        }

        if (insertStmt != null) {
            insertStmt.close();
        }
    }
    //每批数据的插入都要调用一次 invoke() 方法
    @Override
    public void invoke(List<TransFlow> value, Context context) throws Exception {

        //遍历数据集合
        for (TransFlow transFlow : value) {
            insertStmt.setString(1, transFlow.getTradeNo());
            insertStmt.setString(2, transFlow.getTradeName());
            insertStmt.setDouble(3, transFlow.getTrandeAme());
            insertStmt.setInt(4, transFlow.getUserId());
            insertStmt.setString(5, transFlow.getCreateTime());
            insertStmt.addBatch();
        }
        int[] count = insertStmt.executeBatch();//批量后执行
        log.info("Successfully inserted " + count.length + " rows");
    }
}
