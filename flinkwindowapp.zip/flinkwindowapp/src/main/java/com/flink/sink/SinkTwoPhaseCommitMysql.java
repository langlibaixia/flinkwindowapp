/*
 * Copyright (c) 2022. Langlibaixia 834009465@qq.com All Rights Reserved
 *  *  *  Project:   flinktumbleapp
 *  *  *  @ClassName:Sink2PCMySQL
 *  *  *  @Description:侧输出流数据以2PC方式插入mysql数据库表
 *  *  *  Version: 1.0
 *  ***************************************************************************************
 *  *  * 日期        类型   开发者   内容
 *  *  * 2022-04-05 新增   浪里白侠  创建内容
 *  ***************************************************************************************
 */

package com.flink.sink;

import com.flink.pojo.TransTarget;
import com.flink.util.DruidConnectionPool;
import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.java.typeutils.runtime.kryo.KryoSerializer;
import org.apache.flink.api.common.typeutils.base.VoidSerializer;
import org.apache.flink.streaming.api.functions.sink.TwoPhaseCommitSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SinkTwoPhaseCommitMysql extends TwoPhaseCommitSinkFunction<TransTarget, Connection, Void> implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(SinkTwoPhaseCommitMysql.class);
    PreparedStatement insertStmt = null;
    PreparedStatement updateStmt = null;

    // 定义可用的构造函数
    public SinkTwoPhaseCommitMysql() {

        super(new KryoSerializer<>(Connection.class, new ExecutionConfig()), VoidSerializer.INSTANCE);
    }

    @Override
    protected void invoke(Connection connection, TransTarget transTarget, Context context) throws Exception {

        String insert_sql = "insert into transtarget(userid, totalame, starttime, endtime) values(?, ?, ?, ?);";
        String update_sql = "update transtarget set totalame = ? where userid = ? and starttime =? and endtime =?;";
        insertStmt = connection.prepareStatement(insert_sql);
        updateStmt = connection.prepareStatement(update_sql);

        updateStmt.setDouble(1, transTarget.getTotalAme());
        updateStmt.setInt(2, transTarget.getUserId());
        updateStmt.setString(3, transTarget.getStartTime());
        updateStmt.setString(4, transTarget.getEndTime());
        boolean update = updateStmt.execute();
        //log.info("Successfully updated " + updatecount.length + " rows");

        if (update) {
            log.info("Successfully updated ");
        } else {
            insertStmt.setInt(1, transTarget.getUserId());
            insertStmt.setDouble(2, transTarget.getTotalAme());
            insertStmt.setString(3, transTarget.getStartTime());
            insertStmt.setString(4, transTarget.getEndTime());
            insertStmt.execute();
            //insertStmt.addBatch();
            //int[] insertcount = insertStmt.executeBatch();
            if (insertStmt.execute()) {
                log.info("Successfully inserted ");
            }
        }
    }

    @Override
    protected Connection beginTransaction() throws Exception {
        Connection conn = DruidConnectionPool.getConnection();
        System.out.println(conn);
        return conn;
    }

    @Override
    protected void preCommit(Connection connection) throws Exception {
        log.info("start preCommit...");
    }

    @Override
    protected void commit(Connection connection) {
        log.info("start commit...");
        if (connection != null) {
            try {
                connection.commit();
            } catch (SQLException e) {
                log.error("Failed to commit transaction,Connection:" + connection);
                e.printStackTrace();
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void abort(Connection connection) {
        if (connection != null) {
            try {
                connection.rollback();
            } catch (SQLException e) {
                log.error("Transaction rollback failed,Connection:" + connection);
                e.printStackTrace();
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
