/*
 * Copyright (c) 2022. Langlibaixia 834009465@qq.com All Rights Reserved
 *  *  *  Project:   flinktumbleapp
 *  *  *  @ClassName:DruidConnectionPool
 *  *  *  @Description:
 *  *  *  Version: 1.0
 *  ***************************************************************************************
 *  *  * 日期        类型   开发者   内容
 *  *  * 2022-04-04 新增   浪里白侠  创建内容
 *  ***************************************************************************************
 */

package com.flink.app;

import com.alibaba.fastjson.JSONObject;
import com.flink.pojo.TransFlow;
import com.flink.pojo.TransTarget;
import com.flink.sink.SinkBatchMySQL;
import com.flink.sink.SinkTwoPhaseCommitMysql;
import com.flink.util.TimeUtil;
import org.apache.commons.collections.IteratorUtils;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.shaded.curator4.com.google.common.collect.Lists;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.triggers.CountTrigger;
import org.apache.flink.streaming.api.windowing.triggers.PurgingTrigger;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

public class TumbleApplication implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(TumbleApplication.class);

    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(2);
        //env.enableCheckpointing(1000);
        //env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);
        ParameterTool parameters = ParameterTool.fromArgs(args);
        String path = parameters.get("path", null);
        // 默认路径
        String configFilePath = "src\\main\\resources\\conf.properties";

        // 如果参数不为空，使用新路径
        if (path != null) {
            if (path.startsWith("./")) {
                log.error("error: Please use absolute path such as '/opt/...'");
                return;
            }
            configFilePath = path;
        }

        // 读取路径下的文件
        ParameterTool configParameterTool = null;
        try {
            configParameterTool = ParameterTool.fromPropertiesFile(configFilePath);
        } catch (IOException e) {
            if (e instanceof java.io.FileNotFoundException) {
                log.error("error: configFilePath:\"+configFilePath + \" doesn't exist.");
                return;
            }
        }
        Properties props = new Properties();
        //kafka地址
        props.setProperty("bootstrap.servers", configParameterTool.get("bootstrap.servers"));
        //组名
        props.setProperty("group.id", configParameterTool.get("group.id"));

        //字符串序列化和反序列化规则
        props.setProperty("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.setProperty("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

        //offset重置规则
        props.setProperty("auto.offset.reset", configParameterTool.get("auto.offset.reset"));

        //自动提交
        //props.setProperty("enable.auto.commit", "true");
        //props.setProperty("auto.commit.interval.ms", "2000");

        //有后台线程每隔10s检测一下Kafka的分区变化情况
        props.setProperty("flink.partition-discovery.interval-millis", "10000");

        FlinkKafkaConsumer<String> consumer = new FlinkKafkaConsumer<String>(configParameterTool.get("kafka.topic"), new SimpleStringSchema(), props);

        //设置从记录的消费者组内的offset开始消费
        consumer.setStartFromGroupOffsets();

        DataStream<String> kafkaDS = env.addSource(consumer);

        // 转换成TransFlow类型
        DataStream<TransFlow> dataStream = kafkaDS.map(line -> {
            TransFlow transFlow = JSONObject.parseObject(line, TransFlow.class);
            return transFlow;
        });
        dataStream.print("kafka消费到的数据：");

        // 创建水印生产策略
        WatermarkStrategy<TransFlow> wms = WatermarkStrategy
                // 最大容忍的延迟时间
                .<TransFlow>forBoundedOutOfOrderness(Duration.ofSeconds(Long.parseLong(configParameterTool.get("watermark.outOforderness"))))
                // 指定时间戳
                .withTimestampAssigner(
                        (event, timestamp) -> {
                            try {
                                return TimeUtil.dateToTimestamp(event.getCreateTime());
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            return timestamp;
                        });

        //最后的兜底数据
        OutputTag<TransFlow> lateData = new OutputTag<TransFlow>("lateDataOrder") {
        };

        SingleOutputStreamOperator<TransTarget> result = dataStream
                .assignTimestampsAndWatermarks(wms)
                .keyBy(TransFlow::getUserId)
                .window(TumblingEventTimeWindows.of(Time.seconds(Long.parseLong(configParameterTool.get("tumblingtime")))))
                //.trigger(ProcessingTimeoutTrigger.of(ProcessingTimeTrigger.create(), Duration.ofSeconds(30)))
                .allowedLateness(Time.seconds(Long.parseLong(configParameterTool.get("allowedLateness"))))
                // 设置侧输出流
                .sideOutputLateData(lateData)
                .process(new ProcessWindowFunction<TransFlow, TransTarget, Integer, TimeWindow>() {
                    @Override
                    public void process(Integer key, Context context, Iterable<TransFlow> elements, Collector<TransTarget> out) throws Exception {

                        List<TransFlow> list = IteratorUtils.toList(elements.iterator());
                        double total = list.stream().collect(Collectors.summingDouble(TransFlow::getTrandeAme)).doubleValue();

                        TransTarget transTarget = new TransTarget();
                        transTarget.setTotalAme(total);
                        transTarget.setUserId(list.get(0).getUserId());
                        transTarget.setStartTime(TimeUtil.format(context.window().getStart()));
                        transTarget.setEndTime(TimeUtil.format(context.window().getEnd()));
                        out.collect(transTarget);
                    }
                });
        result.print("滚动窗口计算结果：");
        result.addSink(new SinkTwoPhaseCommitMysql());

        DataStream<TransFlow> filterDS = result.getSideOutput(lateData).filter(new FilterFunction<TransFlow>() {
            @Override
            public boolean filter(TransFlow transFlow) {
                return transFlow.getTrandeAme() > 0;
            }
        });
        filterDS.assignTimestampsAndWatermarks(wms)
                .keyBy(new KeySelector<TransFlow, String>() {
                    @Override
                    public String getKey(TransFlow value) throws Exception {
                        return "acencyKey";
                    }
                })
                .window(TumblingEventTimeWindows.of(Time.seconds(Long.parseLong(configParameterTool.get("tumblingtime")))))
                .trigger(PurgingTrigger.of(CountTrigger.of(10)))
                .process(new ProcessWindowFunction<TransFlow, List<TransFlow>, String, TimeWindow>() {
                    @Override
                    public void process(String s, Context context, Iterable<TransFlow> elements, Collector<List<TransFlow>> out) throws Exception {
                        ArrayList<TransFlow> transFlow = Lists.newArrayList(elements);
                        if (transFlow.size() > 0) {
                            System.out.println("收集到transFlow的数据条数是：" + transFlow.size());
                            out.collect(transFlow);
                        }
                    }
                }).addSink(new SinkBatchMySQL());

        env.execute("JOB_TumbleApplication");
    }

}

