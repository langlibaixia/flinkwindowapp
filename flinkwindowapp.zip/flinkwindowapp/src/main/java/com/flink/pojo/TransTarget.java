/*
 * Copyright (c) 2022. Langlibaixia 834009465@qq.com All Rights Reserved
 *  *  *  Project:   flinktumbleapp
 *  *  *  @ClassName:TransTarget
 *  *  *  @Description:
 *  *  *  Version: 1.0
 *  ***************************************************************************************
 *  *  * 日期        类型   开发者   内容
 *  *  * 2022-04-04 新增   浪里白侠  创建内容
 *  ***************************************************************************************
 */

package com.flink.pojo;

public class TransTarget {

    private int userId;
    private double totalAme;
    private String startTime;
    private String endTime;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public double getTotalAme() {
        return totalAme;
    }

    public void setTotalAme(double totalAme) {
        this.totalAme = totalAme;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "TransTarget{" +
                "userId='" + userId + '\'' +
                ", totalAme='" + totalAme + '\'' +
                ", startTime=" + startTime + '\'' +
                ", endTime=" + endTime + '\'' +
                '}';
    }
}
