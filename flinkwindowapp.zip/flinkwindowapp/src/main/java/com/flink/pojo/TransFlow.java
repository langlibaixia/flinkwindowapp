/*
 * Copyright (c) 2022. Langlibaixia 834009465@qq.com All Rights Reserved
 *  *  *  Project:   flinktumbleapp
 *  *  *  @ClassName:WaterSensor
 *  *  *  @Description:
 *  *  *  Version: 1.0
 *  ***************************************************************************************
 *  *  * 日期        类型   开发者   内容
 *  *  * 2022-04-04 新增   浪里白侠  创建内容
 *  ***************************************************************************************
 */

package com.flink.pojo;


public class TransFlow {

    private String tradeNo;
    private String tradeName;
    private double trandeAme;
    private int userId;
    private String createTime;

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public double getTrandeAme() {
        return trandeAme;
    }

    public void setTrandeAme(double trandeAme) {
        this.trandeAme = trandeAme;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "TransFlow{" +
                "tradeNo='" + tradeNo + '\'' +
                ", tradeName='" + tradeName + '\'' +
                ", trandeAme=" + trandeAme +
                ", userId=" + userId +
                ", createTime=" + createTime +
                '}';
    }

}
