/*
 * Copyright (c) 2022. Langlibaixia 834009465@qq.com All Rights Reserved
 *  *  *  Project:   flinktumbleapp
 *  *  *  @ClassName:DruidConnectionPool
 *  *  *  @Description:
 *  *  *  Version: 1.0
 *  ***************************************************************************************
 *  *  * 日期        类型   开发者   内容
 *  *  * 2022-04-05 新增   浪里白侠  创建内容
 *  ***************************************************************************************
 */

package com.flink.util;

import com.alibaba.druid.pool.DruidDataSource;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class DruidConnectionPool implements Serializable {

    // private transient static DataSource dataSource = null;
    private transient static DruidDataSource dataSource = null;
    private transient static Properties properties = new Properties();
    // private static final String DEFAULT_ENCODING = "UTF-8";

    static {
        try {
/*            properties.load(new BufferedInputStream(new FileInputStream("src\\main\\resources\\druid.properties")));
            dataSource = DruidDataSourceFactory.createDataSource(properties);*/
            dataSource = new DruidDataSource();
            dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
            dataSource.setUrl("jdbc:mysql://192.168.1.161:3306/appdb?useUnicode=true&characterEncoding=utf-8");
            dataSource.setUsername("root");
            dataSource.setPassword("@Rq834009465");
            dataSource.setMaxActive(30);
            dataSource.setInitialSize(5);
            dataSource.setMaxWait(3000);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private DruidConnectionPool() {
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

}
